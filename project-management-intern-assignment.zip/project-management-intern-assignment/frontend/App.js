import React from 'react';
import axios from 'axios';

function App() {
  const [message, setMessage] = React.useState("Loading...");
  React.useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL || "http://127.0.0.1:8000"}/`)
      .then(res => setMessage(res.data.message))
      .catch(err => setMessage("Could not reach backend"));
  }, []);
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>Project Management — Intern Assignment</h1>
      <p>{message}</p>
      <p>Open the backend docs at <code>http://127.0.0.1:8000/docs</code></p>
    </div>
  );
}

export default App;
