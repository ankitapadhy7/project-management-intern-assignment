# Project Management — Intern Assignment (Starter)

This repository is a ready-to-upload starter project for the internship assignment.
It includes:
- A FastAPI backend using SQLite (easy to run)
- Simple React frontend scaffold (run `npm install` then `npm start`)
- README and requirements

## How to run (recommended: GitHub Codespaces or local VS Code)

### Backend (Python)
1. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate   # (Windows: .\venv\Scripts\activate)
   ```
2. Install Python requirements:
   ```
   pip install -r requirements.txt
   ```
3. Run the server:
   ```
   uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000
   ```
4. Open docs: http://127.0.0.1:8000/docs

### Frontend (React)
1. cd frontend
2. npm install
3. Create .env with:
   ```
   REACT_APP_API_URL=http://127.0.0.1:8000
   ```
4. npm start

## What is included
- backend/app: minimal FastAPI app, DB models (SQLite), simple CRUD endpoints for users/projects/tasks.
- frontend: very small React scaffold that calls the backend root endpoint.
- requirements.txt and package.json

## Notes
- This is a starter template. Expand models, add auth, and improve validations for production.
- SQLite is used for simplicity. For production use PostgreSQL and Alembic migrations.
