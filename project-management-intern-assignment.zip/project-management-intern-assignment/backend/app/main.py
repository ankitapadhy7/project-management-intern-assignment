from fastapi import FastAPI
from app.api.v1 import users, projects, tasks
from app.db.session import engine, Base

# create db tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Intern Project Management API")

app.include_router(users.router, prefix="/api/v1/users", tags=["users"])
app.include_router(projects.router, prefix="/api/v1/projects", tags=["projects"])
app.include_router(tasks.router, prefix="/api/v1/tasks", tags=["tasks"])

@app.get("/")
def root():
    return {"message": "Welcome to Project Management API 🚀"}
