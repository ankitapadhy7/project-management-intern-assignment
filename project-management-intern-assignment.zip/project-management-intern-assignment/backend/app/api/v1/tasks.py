from fastapi import APIRouter
from typing import List
from app.schemas.task import Task, TaskCreate
from app.db import models
from app.db.session import SessionLocal

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=Task)
def create_task(payload: TaskCreate):
    db = next(get_db())
    task = models.Task(title=payload.title, description=payload.description, project_id=payload.project_id, assignee_id=payload.assignee_id)
    db.add(task)
    db.commit()
    db.refresh(task)
    return task

@router.get("/", response_model=List[Task])
def list_tasks():
    db = next(get_db())
    return db.query(models.Task).all()
