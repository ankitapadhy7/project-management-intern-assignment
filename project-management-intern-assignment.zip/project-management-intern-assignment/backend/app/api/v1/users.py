from fastapi import APIRouter, Depends, HTTPException
from typing import List
from app.schemas.user import User, UserCreate
from app.db import models
from app.db.session import SessionLocal

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=User)
def create_user(payload: UserCreate):
    db = next(get_db())
    # naive: store password as hash placeholder (don't use in prod)
    from app.core.security import get_password_hash
    hashed = get_password_hash(payload.password)
    user = models.User(full_name=payload.full_name, email=payload.email, password_hash=hashed, role=payload.role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.get("/", response_model=List[User])
def list_users():
    db = next(get_db())
    users = db.query(models.User).all()
    return users
