from pydantic import BaseModel, EmailStr
from typing import Optional

class UserBase(BaseModel):
    full_name: str
    email: EmailStr

class UserCreate(UserBase):
    password: str
    role: Optional[str] = "Developer"

class User(UserBase):
    id: int
    role: str

    class Config:
        orm_mode = True
