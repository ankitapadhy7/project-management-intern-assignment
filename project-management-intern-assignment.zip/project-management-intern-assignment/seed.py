from app.db.session import SessionLocal, engine, Base
from app.db import models
from app.core.security import get_password_hash

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    # check existing
    if db.query(models.User).count() == 0:
        u = models.User(full_name='Admin User', email='admin@example.com', password_hash=get_password_hash('password'), role='Admin')
        db.add(u)
    if db.query(models.Project).count() == 0:
        p = models.Project(name='Demo Project', description='Seeded project')
        db.add(p)
    db.commit()
    db.close()
    print('Seed complete')

if __name__ == '__main__':
    seed()
